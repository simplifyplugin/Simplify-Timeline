<?php
/*
	Plugin Name: Zebpay Timeline Plugin
	Version: 1.0.0.0
	Author: Tristonsoft
	Author URI: http://zebpay.com
	Description: This extension for timeline display purpose.
*/


if(!class_exists('ZP_Timeline')){
	class ZP_Timeline{

			public function __construct()
			{
					add_action( 'init', array( $this, 'zpt_init' ) );
					
					
			}
			public function zpt_init(){
						
					$args=array(
						'public'=>true,
						'label'=>'ZEB Timeline',
						'supports'=>array('title','thumbnail','page-attributes','editor','custom-fields'),			
						'rewrite'=>array('slug'=>'zeb_timeline'),
						'menu_icon' => 'dashicons-calendar'
						
						
					);
					register_post_type('zp_timeline',$args);
			}
		
		}
}
if(is_admin()){
	$tsa=new ZP_Timeline();
}

function zpt_load_script()
{
	$styleurl=plugins_url( 'css/style.css', __FILE__ );
	wp_enqueue_style('zpt_style',$styleurl);
}
add_action('wp_enqueue_scripts','zpt_load_script');				

function zbt_loop_shortcode( $atts ) {
			    
			    $args = array(
			        'post_type' => 'zp_timeline',			        
			        'sort_column'   => 'menu_order',
					'orderby' => 'menu_order',
			    );
			    $zbt_query = new  WP_Query( $args );
				$output = '<div class="align"><div id="btc-timeline">';
			    while ( $zbt_query->have_posts() ) : $zbt_query->the_post();
				$time_field=get_post_custom_values('zpdate', $zbt_query->ID);
				$output .= '<div class="entry">';
				$output .= '<div class="entry-date">'.$time_field[0].'</div>';
				$output .= '<div class="entry-info">';
				$output .= '<div class="circle"></div>';
				$output .= '<h4>'.get_the_title().'</h4>';
				$output .= '<p>'.get_the_excerpt().'</p> </div> </div>';
			    endwhile;
			    wp_reset_query();
			    $output .= '</div></div>';
			    return $output;
			}
add_shortcode('andrewloop','zbt_loop_shortcode');
